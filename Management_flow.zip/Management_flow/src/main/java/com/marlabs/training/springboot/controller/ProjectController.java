package com.marlabs.training.springboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.marlabs.training.springboot.entity.Project;
import com.marlabs.traning.springboot.service.ProjectService;

@RestController
@RequestMapping(value="/projects")
public class ProjectController {
	@Autowired
	private ProjectService projectService;
	//@GetMapping(value="/create")
	//@RequestMapping(value="/create")
	@PostMapping(value="/")
	public Project createProject(@RequestBody Project project) {
	return projectService.createProject(project);
	}
	@GetMapping(value="/")
	public List<Project> getAllProject(){
	return projectService.getAllProject();
	}
	

	@PutMapping(value="/{id}")
	public Project updateProjectById(@PathVariable Long id)
	{
		Project project=projectService.getProjectById(id);
		project.setArchived(true);
		return projectService.updateProjectById(project);
	
	}

}
