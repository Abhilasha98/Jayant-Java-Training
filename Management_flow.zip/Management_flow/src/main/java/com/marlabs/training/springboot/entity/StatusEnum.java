package com.marlabs.training.springboot.entity;

public enum StatusEnum {
	INPROGRESS,
	FINISHED;
	

}
