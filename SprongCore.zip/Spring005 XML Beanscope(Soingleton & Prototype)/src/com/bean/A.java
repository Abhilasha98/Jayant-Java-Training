package com.bean;

public class A {

}
