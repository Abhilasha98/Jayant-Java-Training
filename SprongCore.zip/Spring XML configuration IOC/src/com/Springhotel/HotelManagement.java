package com.Springhotel;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class HotelManagement {
	public static void main(String[] args) {
		//Load the  configuration file
	ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("Spring.Xml");	
		//retrieve the bean from spring container
	Chef chef =ctx.getBean("iChef",Chef.class);
		//call the methods
	System.out.println(chef.prepareFood());
	//close the context
	ctx.close();
	}

}

