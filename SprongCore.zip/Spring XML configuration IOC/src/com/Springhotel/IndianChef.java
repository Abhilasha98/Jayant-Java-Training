package com.Springhotel;

public class IndianChef implements Chef{

	@Override
	public String prepareFood() {
		// TODO Auto-generated method stub
		return "Tandoori Chicken";
	}

}
