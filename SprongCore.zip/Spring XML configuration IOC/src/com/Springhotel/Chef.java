package com.Springhotel;

public interface Chef {
 public String prepareFood();
}
