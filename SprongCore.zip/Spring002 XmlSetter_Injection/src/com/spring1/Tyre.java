package com.spring1;

public class Tyre {
	public String move() {
		return"moving with the speed of 120km/hr";
		
	}

}
