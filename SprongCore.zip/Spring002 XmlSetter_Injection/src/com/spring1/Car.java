package com.spring1;

public class Car {
private Tyre t;
//provide setter for injection
public void setT(Tyre t) {
	this.t = t;
}


void letsGo(){
	System.out.println("we are going to Mysore");
	System.out.println(t.move());
}


}
