package com.spring1;

import org.springframework.context.support.ClassPathXmlApplicationContext;


public class SpringApp {
public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
	// TestBean e =ctx.getBean("testBean",TestBean.class);
	 TBean e =ctx.getBean("TBean",TBean.class);
	 ctx.close();
}
}
