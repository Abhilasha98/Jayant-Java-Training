package com.spring1;
import org.springframework.stereotype.Component;

@Component
public class TBean {

	public TBean() {
		System.out.println("DC-Test Bean");
	}
	

}
