package com.spring1;
import org.springframework.stereotype.Component;

@Component
public class TestBean {
	

	
	public TestBean() {
		
	System.out.println("DC-Test Bean");
	}

}
