package com.springpackage;

public class TestBeanclass {
	public TestBeanclass() {
		System.out.println("DC:Test Bean");
	}
	
public void MyInit() {
	System.out.println("Init TestBean");
	
	
	
}
public void mydestroy() {
	System.out.println("Destroy test bean");
	
}
}
