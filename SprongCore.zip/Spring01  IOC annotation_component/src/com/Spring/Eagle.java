package com.Spring;

import org.springframework.stereotype.Component;

@Component("eagle")
public class Eagle implements Bird {
public void fly() {
	System.out.println("i can fly");
}
}
