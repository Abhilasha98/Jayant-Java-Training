package com.Spring;

public interface Bird {
	public void fly();
		
	}


