package com.spring3;

public interface Diet {
	public void eat();

}
