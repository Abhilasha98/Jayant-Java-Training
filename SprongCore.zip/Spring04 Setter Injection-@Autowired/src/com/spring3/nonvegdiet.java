package com.spring3;

import org.springframework.stereotype.Component;

@Component
public class nonvegdiet implements Diet {

	@Override
	public void eat() {
		System.out.println("red and juice meat");
		
	}

}
