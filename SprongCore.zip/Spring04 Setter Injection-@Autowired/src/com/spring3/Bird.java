package com.spring3;

public interface Bird {
public void eatingstyle();
}
