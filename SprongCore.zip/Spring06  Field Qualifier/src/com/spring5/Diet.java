package com.spring5;

public interface Diet {
public void eat();
}
