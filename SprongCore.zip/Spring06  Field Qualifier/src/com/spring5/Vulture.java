package com.spring5;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Vulture implements Bird{
	@Qualifier("nonvegdiet")
@Autowired
	Diet diet;
	
	
	


	@Override
	public void eatingstyle() {
		diet.eat();
		
	}

}
