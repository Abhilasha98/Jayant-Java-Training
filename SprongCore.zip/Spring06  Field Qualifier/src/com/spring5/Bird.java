package com.spring5;

public interface Bird {
	public void eatingstyle();

}
