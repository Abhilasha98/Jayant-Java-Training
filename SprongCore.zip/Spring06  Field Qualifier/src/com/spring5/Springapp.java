package com.spring5;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Springapp {

	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
Bird b = ctx.getBean("vulture",Bird.class);
b.eatingstyle();
ctx.close();
	}

}
