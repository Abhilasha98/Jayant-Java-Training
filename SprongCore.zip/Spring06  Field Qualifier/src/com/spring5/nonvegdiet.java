package com.spring5;

import org.springframework.stereotype.Component;

@Component
public class nonvegdiet implements Diet {

	@Override
	public void eat() {
		// TODO Auto-generated method stub
		System.out.println(" rice and juice meat ");
	}
	

}
