package com.spring4;

public interface Diet {
	public void eat();

}
