package com.spring4;

public interface Bird {
	public void eatingstyle();

}
