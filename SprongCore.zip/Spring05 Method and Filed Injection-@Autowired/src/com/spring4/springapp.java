package com.spring4;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class springapp {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
	Bird bird =	ctx.getBean("vulture",Bird.class);
	bird.eatingstyle();
	ctx.close();
		
	}
}
