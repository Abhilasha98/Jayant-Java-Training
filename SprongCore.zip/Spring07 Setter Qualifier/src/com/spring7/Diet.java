package com.spring7;

public interface Diet {
	public void eat();

}
