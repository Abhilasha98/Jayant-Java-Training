package com.spring7;

public interface Bird {
	public void eatingstyle();

}
