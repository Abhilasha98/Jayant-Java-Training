package com.spring7;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Stringapp {
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
		Bird b = ctx.getBean("vulture",Bird.class);
		b.eatingstyle();
		ctx.close();
	}
	

}
