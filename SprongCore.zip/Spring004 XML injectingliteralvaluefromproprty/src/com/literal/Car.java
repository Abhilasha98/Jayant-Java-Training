package com.literal;

public class Car {
private Tyre t;
private String brand;
private String model;

//provide setter for injection
public void setT(Tyre t) {
	this.t = t;
}


public String getBrand() {
	return brand;
}


public void setBrand(String brand) {
	this.brand = brand;
}


public String getModel() {
	return model;
}


public void setModel(String model) {
	this.model = model;
}


void letsGo(){
	System.out.println("we are going to Mysore");
	System.out.println(t.move());
}


}
