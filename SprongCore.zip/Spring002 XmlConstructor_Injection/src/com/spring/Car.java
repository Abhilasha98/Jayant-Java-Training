package com.spring;

public class Car {
private Tyre t;



 


/*public void setT(Tyre t) {
	this.t = t;
}*/

//provide constructor for injection

public Car(Tyre t) {
	super();
	this.t = t;
}



void letsGo(){
	System.out.println("we are going to Mysore");
	System.out.println(t.move());
}


}
