package com.spring2;

public interface Bird {
public void eatingstyle();
}
