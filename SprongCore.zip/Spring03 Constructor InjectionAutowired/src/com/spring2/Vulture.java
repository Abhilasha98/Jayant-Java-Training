package com.spring2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
@Component
public class Vulture implements Bird {
  Diet diet;
  
  
 


@Autowired
	public Vulture(Diet diet) {
	super();
	this.diet = diet;
}






	@Override
	public void eatingstyle() {
		diet.eat();
		
		
	}



	

}
