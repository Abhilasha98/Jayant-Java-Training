package com.spring2;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Springapp {
	
	public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
	Bird bird = ctx.getBean("vulture",Bird.class);
	bird.eatingstyle();
	ctx.close();
	}
}
