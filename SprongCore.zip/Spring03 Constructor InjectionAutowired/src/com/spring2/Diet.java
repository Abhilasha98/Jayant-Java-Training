package com.spring2;

public interface Diet {
	public void eat();

}
