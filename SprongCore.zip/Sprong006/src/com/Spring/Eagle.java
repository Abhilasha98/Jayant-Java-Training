package com.Spring;

public class Eagle {
public void fly() {
	System.out.println("i can fly");
}
}
