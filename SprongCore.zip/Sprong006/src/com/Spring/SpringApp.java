package com.Spring;


import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

@Component("Eagle")
public class SpringApp {
	public static void main(String[] args) {
	ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("Spring.xml");
	Eagle e = ctx.getBean("Eagle",Eagle.class);
	e.fly();

	ctx.close();
	
}
}
