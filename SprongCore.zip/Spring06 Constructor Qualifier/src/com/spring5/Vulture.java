package com.spring5;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

@Component
public class Vulture implements Bird {

//@Autowired//	
Diet diet;
@Autowired
public Vulture(@Qualifier("vegdiet")Diet diet) {
	super();
	this.diet = diet;
}


	@Override
	public void eatingstyle() {
		diet.eat();
		
	}

}
