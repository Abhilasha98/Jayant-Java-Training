package com.spring5;

import org.springframework.stereotype.Component;

@Component
public class Vegdiet implements Diet {

	@Override
	public void eat() {
		System.out.println("Grass and Tomato");
		
	}

}
