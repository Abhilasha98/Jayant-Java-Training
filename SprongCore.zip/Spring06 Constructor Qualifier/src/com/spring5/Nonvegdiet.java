package com.spring5;

import org.springframework.stereotype.Component;

@Component
public class Nonvegdiet implements Diet{

	@Override
	public void eat() {
		System.out.println("rice and meal");
	}

}
