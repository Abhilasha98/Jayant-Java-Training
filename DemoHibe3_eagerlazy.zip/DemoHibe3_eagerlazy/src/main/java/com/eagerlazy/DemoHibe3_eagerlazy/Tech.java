package com.eagerlazy.DemoHibe3_eagerlazy;

public class Tech {

}
