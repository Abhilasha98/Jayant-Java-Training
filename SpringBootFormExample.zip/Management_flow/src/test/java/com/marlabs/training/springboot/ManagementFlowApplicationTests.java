package com.marlabs.training.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManagementFlowApplicationTests {

	@Test
	void contextLoads() {
	}

}
