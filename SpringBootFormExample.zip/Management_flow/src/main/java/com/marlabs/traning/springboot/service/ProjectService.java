package com.marlabs.traning.springboot.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.marlabs.training.springboot.dao.ProjectDao;
import com.marlabs.training.springboot.entity.Project;

@Service
public class ProjectService {
	
	@Autowired
	private ProjectDao projectDao;
	public Project createProject(Project project) {
	return projectDao.save(project);
	}
	//get all student
	public List<Project> getAllProject(){
	return (List) projectDao.findAll();
	}
	public Project getProjectById(Long id) {
	Optional<Project> optionalEntity=projectDao.findById(id);
	Project project=optionalEntity.get();
	return project;
	}

	
	 public Project updateProjectById(Project project) {
	return projectDao.save(project);
	}

	}


