package com.marlabs.training.springboot.dao;

import org.springframework.data.repository.CrudRepository;

import com.marlabs.training.springboot.entity.Project;

public interface ProjectDao extends CrudRepository<Project,Long> { 

}
