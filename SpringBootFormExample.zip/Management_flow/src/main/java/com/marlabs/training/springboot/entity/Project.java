package com.marlabs.training.springboot.entity;



import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;




@Entity
@Table(name="projecttbl")
public class Project {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	private String name;
	@Enumerated(EnumType.ORDINAL)
	private StatusEnum status;
	
	
	private Date dateCreated = new Date(System.currentTimeMillis()); 
	private boolean archived;
	
	public Date getDateCreated() {
		return dateCreated;
	}
	public void setDateCreated(Date dateCreated) {
		this.dateCreated = dateCreated;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public StatusEnum getStatus() {
	return status;
	}
	public void setStatus(StatusEnum status) {
		this.status = status;
	}
	
	
	public boolean isArchived() {
		return archived;
	}
	public void setArchived(boolean archived) {
		this.archived = archived;
	}
	public Project(Long id, String name, StatusEnum status, boolean archived) {
		super();
		this.id = id;
		this.name = name;
		this.status = status;
	
		this.archived = archived;
	}
	public Project() {
		super();
		// TODO Auto-generated constructor stub
	}
	


}
