package com.marlabs.training.object;

public class Employee {
	int id;
	String name;
	int salary;
	void doJob() {
		System.out.println("employee work");
	}
	void eat() {
		System.out.println("employee eat");
	}
}

class EmployeeApp {

	public static void main(String[] args) {
Employee e1 = new Employee();
e1.id=213;
e1.name="Abhi";
e1.salary=20999;
e1.doJob();
e1.eat();
System.out.print(e1.id);
System.out.print(e1.name);
System.out.print(e1.salary);
	}
	

}

