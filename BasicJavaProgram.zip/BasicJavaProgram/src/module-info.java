/**
 * 
 */
/**
 * 
 */
module BasicJavaProgram {
}