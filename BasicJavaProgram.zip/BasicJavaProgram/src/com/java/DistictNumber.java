package com.java;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class DistictNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer> l1 = Arrays.asList(2,2,10,10,14,560);
l1.stream().distinct().collect(Collectors.toList());
System.out.println(l1);
//forEach(System.out::println);
	}

}
