package com.java;

import java.util.ArrayList;
import java.util.LinkedList;

public class ArrayListToLinkdList {
	public static void main(String[] args) {
ArrayList<Integer> a1 = new ArrayList<>();
a1.add(20);
a1.add(30);
a1.add(40);
a1.add(50);

LinkedList<Integer> l1 = new LinkedList<>();
//l1.addAll(a1);
System.out.println(l1);
}
}