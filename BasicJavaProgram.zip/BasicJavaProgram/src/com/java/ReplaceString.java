package com.java;

public class ReplaceString {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
String str1 = "abhuijfgs123@ jdueaakr";
// str1= str1.replace("a", "_");//treat first input as a normal text
//String str2  = str1.replaceAll("\\d", "_");//remove digits with underscore  treat first argument as regular expression
//String str3  = str1.replaceAll("\\s", "_");//remove space with underscore
String str4 = str1.replaceAll("[^a-zA-Z]","_");//replace everything except letter ^ not a letter
//System.out.println(str2);
//System.out.println(str3);
System.out.println(str4);




	}

}
