package com.java;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class Stream {

	public static void main(String[] args) {
List<Integer> l1 = Arrays.asList(8,6,4,2,3,5,6,7);
//int max= Collections.max(l1);
//int min= Collections.min(l1);
//long a2 = l1.stream().count();//Count the numbers
//System.out.println(a2);
//List<Integer> reverseList= l1.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());//highest to lowest
//l1.stream().filter(n->n>5).forEach(System.out::println);// greater then 5 number will return
//l1.stream().filter(n->n%2!=0).forEach(System.out::println);//PRINT even Number filer(n%2==0) even
//l1.stream().distinct().sorted().forEach(System.out::println);// sorted(low to highest) and distinct
////System.out.println(reverseList);
//System.out.println(max);
//System.out.println(min);
//List<Integer> l2 = l1.stream().map(n->n*n).collect(Collectors.toList());
List<Integer> l2 = l1.stream().map(n->n+n).collect(Collectors.toList());
//List<Integer> l2 = l1.stream().map(n->n*3).collect(Collectors.toList());


System.out.println(l2);


LocalDate date =LocalDate.now();
LocalTime time= LocalTime.now();
LocalDateTime dateTime= LocalDateTime.now();
System.out.println(date);
System.out.println(dateTime);
System.out.println(time);


	}

}
