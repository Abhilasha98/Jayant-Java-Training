package com.java;

public class ReverseString {

	public static void main(String[] args) {
String str="JAVA";
String a1 = new StringBuilder(str).reverse().toString();
System.out.println(a1);
	}

}
