package com.java;

public class LengthString {

	public static void main(String[] args) {
String str= "Hello World";
long count = str.chars().filter(Character::isLetter).count();
System.out.println(count);

	}

	
}
