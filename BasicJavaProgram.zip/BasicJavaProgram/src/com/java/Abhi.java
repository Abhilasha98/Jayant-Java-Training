package com.java;

public class Abhi {

	public static void main(java.lang.String[] args) {
String str="ABHI HI";
String[] a1= str.split(" ");
int count = a1.length;
System.out.println(+ count);

	}

}
