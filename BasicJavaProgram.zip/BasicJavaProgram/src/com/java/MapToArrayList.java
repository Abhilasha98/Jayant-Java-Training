package com.java;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class MapToArrayList {

	public static void main(String[] args) {
Map<Integer, String> m1 = new HashMap<>();
m1.put(1, "abhi");
m1.put(2, "dee");
m1.put(3, "amruta");
m1.put(3, "affrena");

ArrayList<Integer> l1 = new ArrayList<>(m1.keySet());
System.out.println(l1);
System.out.println(m1);



	}

}
