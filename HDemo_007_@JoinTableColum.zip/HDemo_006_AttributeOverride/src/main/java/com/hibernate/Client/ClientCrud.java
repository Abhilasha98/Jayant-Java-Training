package com.hibernate.Client;

import com.hibernate.Entity.Employee;
import com.hibernate.Service.EmployeeService;
import com.hibernate.Service.impl.EmployeeServiceimpl;
import com.hibernate.model.Address;



public class ClientCrud {
	public static void main(String[] args) {
		EmployeeService employeeService= new EmployeeServiceimpl();
		try {
			Address localAddress= new Address(1092,5,21,"barkur","karnataka",9876567);
			Address permAddress= new Address(4092,51,2,"udupi","karnataka",98798568);
			Employee employee=new Employee("Abhilasha","ab@gmail.com",8000.0);
			employee.setLocaladress(localAddress);
			employee.setPermadress(permAddress);
			Integer i=employeeService.saveEmployee(employee);
			System.out.println("Employee is created with Id:"+i);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
