package com.hibernate.Client;

import com.hibernate.Entity.Employee;
import com.hibernate.Service.EmployeeService;
import com.hibernate.Service.impl.EmployeeServiceimpl;
import com.hibernate.model.Address;



public class ClientCrud {
	public static void main(String[] args) {
		EmployeeService employeeService= new EmployeeServiceimpl();
		try {
			Address address= new Address(1092,5,21,"barkur","karnataka",9876567);
			Employee employee=new Employee("Abhilasha","ab@gmail.com",8000.0);
			employee.setAdress(address);
			Integer i=employeeService.saveEmployee(employee);
			System.out.println("Employee is created with Id:"+i);
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
}
