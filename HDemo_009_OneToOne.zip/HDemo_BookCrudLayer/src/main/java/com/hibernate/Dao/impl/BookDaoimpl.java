package com.hibernate.Dao.impl;

import org.hibernate.HibernateException;
import org.hibernate.Session;

import com.hibernate.Dao.BookDao;
import com.hibernate.Entity.Book;

import com.hibernate.Util.HibernateUtil;

public class BookDaoimpl implements BookDao {

	public int saveBook(Book book) {
		Integer id=0;
		try (Session session = HibernateUtil.getSessionFactory().openSession()){
			session.beginTransaction();
			id=(Integer)session.save(book);
			session.getTransaction().commit();
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return id;
	}

	public Book getBookById(int bookId) {
		Book book= null;
		try (Session session = HibernateUtil.getSessionFactory().openSession()){
			book= session.get(Book.class, bookId);
			if(book!=null) {
				System.out.println("Book Found!");
			}
			else {
				System.out.println("Book not Fount with Id: "+bookId);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
		return book;
	}

	public void updateBookById(int bookId, Book bookTO) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()){
			Book book= session.get(Book.class, bookId);
			if(book!= null) {
				
				//employee.setEmployeeName(employeeTO.getEmployeeName());
				//employee.setEmail(employeeTO.getEmail() );
				book.setPrice(bookTO.getPrice());
				
				session.beginTransaction();
				session.update(book);
				session.getTransaction().commit();
			}
			else {
				System.out.println("Book Not found!!");
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}

	public void deleteBookById(int bookId) {
		try (Session session = HibernateUtil.getSessionFactory().openSession()){
			Book book= session.get(Book.class, bookId);
			if(book!= null) {
				session.beginTransaction();
				session.delete(book);
				session.getTransaction().commit();
			}
			else {
				System.out.println("Book not Fount with Id: "+bookId);
			}
		} catch (HibernateException e) {
			e.printStackTrace();
		}
	}
	}


