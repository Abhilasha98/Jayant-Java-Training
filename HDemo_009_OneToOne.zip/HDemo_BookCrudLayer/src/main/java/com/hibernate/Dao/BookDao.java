package com.hibernate.Dao;

import com.hibernate.Entity.Book;

public interface BookDao {
	public int saveBook(Book book);
	public Book getBookById(int bookId);
	public void updateBookById(int bookId, Book bookTO);
	public void deleteBookById(int bookId);
}
