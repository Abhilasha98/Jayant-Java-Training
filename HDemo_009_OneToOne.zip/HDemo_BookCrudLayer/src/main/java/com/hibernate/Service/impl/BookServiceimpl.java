package com.hibernate.Service.impl;

import com.hibernate.Dao.BookDao;
import com.hibernate.Dao.impl.BookDaoimpl;

import com.hibernate.Entity.Book;
import com.hibernate.Service.BookService;

public class BookServiceimpl implements BookService {
	BookDao bookDao= null;

	public int saveBook(Book book) {
		bookDao= new BookDaoimpl();
		return bookDao.saveBook(book);
		// TODO Auto-generated method stub
		
	}

	public Book getBookById(int bookId) {
		bookDao= new BookDaoimpl();
		return bookDao.getBookById(bookId);
	}

	public void updateBookById(int bookId, Book bookTO) {
		bookDao= new BookDaoimpl();
		bookDao.updateBookById(bookId, bookTO);

	}

	public void deleteBookById(int bookId) {
		bookDao= new BookDaoimpl();
		bookDao.deleteBookById(bookId);
	}

}
