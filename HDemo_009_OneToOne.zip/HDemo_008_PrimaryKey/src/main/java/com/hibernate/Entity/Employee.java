package com.hibernate.Entity;
import java.util.ArrayList;
import java.util.Collection;

import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.Table;

import org.hibernate.annotations.Type;


import org.hibernate.annotations.CollectionId;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.GenericGenerator;

import com.hibernate.model.Address;

 

@Entity
@Table(name="empl2_tbl")
@DynamicUpdate
public class Employee {
	@Id
	@Column(name="emp_id")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer employeeId;
	
	@Column(name="emp_name")
	private String employeeName;
	
	private String email;
	
	private Double salary;
	@ElementCollection
	@JoinTable(name="address2_tbl",joinColumns=@JoinColumn(name="employee_id"))
	@GenericGenerator(name="seq_gen",strategy="sequence")
	@CollectionId(columns= {@Column(name="address_id")},generator="seq_gen", type= @Type(type="int"))
	public Collection<Address> addresses= new ArrayList<Address>();
	
	public Integer getEmployeeId() {
		return employeeId;
	}

	public void setEmployeeId(Integer employeeId) {
		this.employeeId = employeeId;
	}

	public String getEmployeeName() {
		return employeeName;
	}

	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Double getSalary() {
		return salary;
	}

	public void setSalary(Double salary) {
		this.salary = salary;
	}
	
	

	


	

	

	
	public Collection<Address> getAddresses() {
		return addresses;
	}

	public void setAddresses(Collection<Address> addresses) {
		this.addresses = addresses;
	}

	public Employee(String employeeName, String email, Double salary) {
		super();
		this.employeeName = employeeName;
		this.email = email;
		this.salary = salary;
	}

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		String result="------------------\nEMPLOYEE Details:\n------------------\n Employee Id: "+employeeId+"\n Employee Name: "+employeeName+"\n Email: "+email+"\n Salary: "+salary;
		return result;
	}
	
	
}