package com.hibernate.Dao;

import com.hibernate.Entity.Employee;

public interface EmployeeDao {
	public int saveEmployee(Employee employee);
	public Employee getEmployeeById(int employeeId);
	public void updateEmployeeById(int employeeId, Employee employeeTO);
	public void deleteEmployeeById(int employeeId);
   
}
