package com.hibernate.Service;

import com.hibernate.Entity.Employee;

public interface EmployeeService {
	public int saveEmployee(Employee employee);
	public Employee getEmployeeById(int employeeId);
	public void updateEmployeeById(int employeeId, Employee employeeTO);
	public void deleteEmployeeById(int employeeId);

}
