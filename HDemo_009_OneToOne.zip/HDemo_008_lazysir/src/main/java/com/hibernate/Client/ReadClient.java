package com.hibernate.Client;

import com.hibernate.Entity.Employee;
import com.hibernate.Service.EmployeeService;
import com.hibernate.Service.impl.EmployeeServiceimpl;

public class ReadClient {
	public static void  main(String[] args) {
		EmployeeService employeeService=null;
		Employee employee=null;
		try {
			employeeService = new EmployeeServiceimpl();
			employee = employeeService.getEmployeeById(1);
			System.out.println(employee);
			System.out.println("-----------------------");
			employee.getAddresses().forEach(System.out::println);
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}

}
