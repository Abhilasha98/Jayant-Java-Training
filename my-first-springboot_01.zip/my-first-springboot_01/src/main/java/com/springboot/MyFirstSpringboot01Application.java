package com.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyFirstSpringboot01Application {

	public static void main(String[] args) {
		SpringApplication.run(MyFirstSpringboot01Application.class, args);
	}

}
