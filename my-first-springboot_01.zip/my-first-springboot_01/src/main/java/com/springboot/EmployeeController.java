package com.springboot;

import java.util.ArrayList;
import java.util.List;

public class EmployeeController {
	List<Employee> employeelist=new ArrayList();
	
	

}
