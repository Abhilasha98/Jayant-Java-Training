package com.marlabs.training.enumtutorial;

import com.enu.Colors;

public class Main {
	public static void main(String[] args) {

		Colors x = Colors.GREEN;

		switch (x) {
		case RED:
			System.out.println("x has red colour");
			break;
		case GREEN:
			System.out.println("x has Green colour");
			break;
		case BLUE:
			System.out.println("x has blue colour");
			break;
		}

	}

}
