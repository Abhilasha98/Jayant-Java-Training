package Programs;

import java.util.Scanner;
//without using temporary variable
public class SwapNumber {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter two numbers");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		System.out.println("before swaping of two number:"+n1+n2);
		n1=n1+n2;//9
		n2=n1-n2;//9-5=4
		n1=n1-n2;//9-4=5
		System.out.println("after swaping of two number:"+n1+n2);
		}


}
