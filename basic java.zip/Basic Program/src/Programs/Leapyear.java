package Programs;

import java.util.Scanner;

public class Leapyear {
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("please enter year");
	int year=sc.nextInt();

	if(year%4==0 ||year%400==0&&year%100!=0)
	System.out.println("given year is leap year:"+year);
	else
	System.out.println("given year is not leap year:"+year);


//year is divisible by 4 is leap yr or it is divisible by 400 and is not divisible by 100 is leap yr

	}
}
