package Programs;

import java.util.Scanner;

public class ReverseString {
	
	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("please enter string");
	String s=sc.nextLine();
	String s2="";
	int size=s.length();
	for(int i=size-1;i>=0;i--) {
	s2=s2+s.charAt(i);
	}
	System.out.println(s2);
	if(s.equals(s2))
	System.out.println("given string is palindrome:"+s);
	else
	System.out.println("given string is not palindrome:"+s);
	}}



