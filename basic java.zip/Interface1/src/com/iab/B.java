package com.iab;

abstract public class B implements A {
	public void c(){System.out.println("I am c");

}
}
