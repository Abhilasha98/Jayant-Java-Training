package com.iab;

public class TestApp {
	public static void main(String args[]){  
		A a=new M();  
		a.a();  
		a.b();  
		a.c();  
		a.d();  
		}}  
//M m = new M();
//A ref;
//ref=m;
//ref.a();
