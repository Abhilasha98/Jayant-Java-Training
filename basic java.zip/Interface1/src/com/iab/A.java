package com.iab;

public interface A {
public void a();
	
	public void b();  
    public	void c();  
	public void d();  

}
