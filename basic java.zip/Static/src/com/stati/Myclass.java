package com.stati;

class MyClass {
    public static void main(String args[]) {
        Car c = new Car();
    }
}
