package com.stati;

public class Car {

}
//