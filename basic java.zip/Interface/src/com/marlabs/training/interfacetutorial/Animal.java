package com.marlabs.training.interfacetutorial;

public interface Animal {
	default void foodHabits() {
		System.out.println("carnivorous");
	}

	static void weight() {
		System.out.println("20kg");

	}

	public void run();
}
