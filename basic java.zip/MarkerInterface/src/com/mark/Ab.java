package com.mark;

public class Ab  implements Marker{

}
