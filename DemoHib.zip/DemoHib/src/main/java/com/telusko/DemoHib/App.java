package com.telusko.DemoHib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;


/**
 * Hello world!
 *
 */
public class App 
{
	private static StandardServiceRegistry standardServiceRegistry;
    public static void main( String[] args )
    {
    	AlienName an = new AlienName();
    	an.setFname("abhin");
    	an.setLname("shetty");
    	an.setMname("shwetha");
    	
    	
        Alien telusko=new Alien();
        
        telusko.setAid(104);
     
        telusko.setColor("yellow");
        telusko.setAname(an);
        
        
        Configuration con = new Configuration().configure().addAnnotatedClass(Alien.class);
        ServiceRegistry reg= new StandardServiceRegistryBuilder().applySettings(con.getProperties()).build();
        SessionFactory sf= con.buildSessionFactory(reg);
       Session session = sf.openSession();
       Transaction tx = session.beginTransaction();
      // telusko=(Alien)session.get(Alien.class, 102);
      session.save(telusko);
      tx.commit();
      System.out.println(telusko);
    }
}
